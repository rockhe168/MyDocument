(function(){
	var isSEO=/\/html5\//i.test(location.href.replace(/[\?#].+$/,''));
	if (isSEO){
		// add base tag for seo
		var head=document.getElementsByTagName('head')[0];
		var base=document.createElement('base');
		base.href=location.href.replace(/\/html5\//i,'/webapp/');
		if (head.firstChild){
			head.insertBefore(base,head.firstChild);
		}else{
			head.appendChild(base);
		}
	}
})();

;$(function(){
	
    window.siteBaseUrl = document.getElementById('siteBaseUrl');
    siteBaseUrl = siteBaseUrl ? siteBaseUrl.value : location.href.replace(/[\?#].*$/,'').replace(/[^\/]*$/,'');
	var homeUrl = window.location.href;
	var starter = $(document).ready;
	var $doc = $(document);
	var $head = $('head');
	var $body = $(document.body);
	// var hist = [];
	var tapHandlers = [];
	
	var toolbarClass = 'toolbar';
	var backClass="back";
	var sectionID = 'main';
	var animForwardName = 'lizard-animation-left';
	var animBackwardName = 'lizard-animation-right';
	var animInName = 'lizard-animation-in';
	var animOutName = 'lizard-animation-out';
	var currentClass='lizard-animation-current';
	var backStr = '<i id="c-ui-header-return" class="returnico i_bef"></i>';
	var homeStr = '<i class="icon_home i_bef" id="c-ui-header-home"></i>';

	var section = document.getElementById(sectionID);
	var $section = $(section);
	var $header = $('header');

	
	var $viewport = $section.find('.main-viewport');
	var $statedom = $section.find('.main-state');
	var viewsData = {};
	var support = window.history && window.history.pushState && window.history.replaceState;
	var loaderBody = [
		'<div class="cui-view cui-layer cui-loading" id="cui-1398003034712" style="visibility: visible; margin-left: -45px; margin-top: -40px; z-index: 3031; /* display: none; */"><div class="cui-layer-padding"><div class="cui-layer-content"><div class="cui-breaking-load"><div class="cui-i cui-w-loading"></div><div class="cui-i cui-m-logo"></div></div></div></div></div>',
		'<div class="cui-view cui-mask cui-opacitymask" id="cui-1398003034713" style="position: absolute; left: 0px; top: 0px; width: 100%; height: 2714px; z-index: 3029; /* display: none; */"><div></div></div>'].join("");

	// modify by cdchu start
	var loaderStyle='.main-viewport>div {\r\n\tdisplay: none;\r\n\t-webkit-animation-duration: 350ms;\r\n\t-webkit-animation-fill-mode: both;\r\n\t-webkit-animation-timing-function: ease-in-out;\r\n\tbackface-visibility: hidden;  \r\n\t-webkit-backface-visibility: hidden; /* Chrome and Safari */  \r\n\t-moz-backface-visibility: hidden; /* Firefox */  \r\n}\r\n\r\n.main-viewport>div.lizard-animation-current {\r\n\tdisplay: block\r\n}\r\n@-webkit-keyframes lizard-animation-leftIn {\r\n\tfrom {\r\n\t\t-webkit-transform: translateX(100%)\r\n\t}\r\n\tto {\r\n\t\t-webkit-transform: translateX(0)\r\n\t}\r\n}\r\n@-webkit-keyframes lizard-animation-leftOut {\r\n\tfrom {\r\n\t\t-webkit-transform: translateX(0)\r\n\t}\r\n\tto {\r\n\t\t-webkit-transform: translateX(-100%)\r\n\t}\r\n}\r\n.main-viewport>div.lizard-animation-left.lizard-animation-in {\r\n\t-webkit-animation-name: lizard-animation-leftIn\r\n}\r\n.main-viewport>div.lizard-animation-left.lizard-animation-out {\r\n\t-webkit-animation-name: lizard-animation-leftOut\r\n}\r\n@-webkit-keyframes lizard-animation-rightIn {\r\n\tfrom {\r\n\t\t-webkit-transform: translateX(-100%)\r\n\t}\r\n\tto {\r\n\t\t-webkit-transform: translateX(0)\r\n\t}\r\n}\r\n@-webkit-keyframes lizard-animation-rightOut {\r\n\tfrom {\r\n\t\t-webkit-transform: translateX(0)\r\n\t}\r\n\tto {\r\n\t\t-webkit-transform: translateX(100%)\r\n\t}\r\n}\r\n\r\n.main-viewport>div.lizard-animation-right.lizard-animation-in {\r\n\t-webkit-animation-name: lizard-animation-rightIn\r\n}\r\n.main-viewport>div.lizard-animation-right.lizard-animation-out {\r\n\t-webkit-animation-name: lizard-animation-rightOut\r\n}\r\n';

	function addLoaderStyle(css){
		$head.append('<style type="text/css">' + css + '</style>')
	}
	// modify by cdchu end

	// modify by cdchu start
	function getGuid(){
		return +new Date();
	}
	// modify by cdchu end

	function addLoader(){
		$body.append('<div class="fullscreen"></div><div class="loader">' + loaderBody + '</div>')
	}
	function showLoader(){
		$('#cui-1398003034713').show();
		$('#cui-1398003034712').show();
	}
	function hideLoader(){
		$('#cui-1398003034713').hide();
		$('#cui-1398003034712').hide();
	}
	function addBackAndHome(){
		$header.append(backStr);
		$header.append(homeStr);

	}
	function removeBackAndHome(){
		$('#c-ui-header-return').remove();
		$('#c-ui-header-home').remove();
	}


	function addCurrent(url){
		var el = document.getElementById(url);
		$(el).addClass(currentClass);
	}
	function removeCurrent(){
		$('.'+currentClass).removeClass(currentClass);
	}

	function getID(url){
		var id=url;
		id = id.replace(/\//g,'');
		id = id.replace(/\:/g,'');
		return id;
	}

	function showView(data){
		data=data||showView.firstState;
		var url=data.url;
		var id=data.id||"$"+getGuid()+"|"+escape(url).replace(/%/g,'$');
		//var id=data.id||showView.isFirst?url:"$"+getGuid()+"|"+escape(url).replace(/%/g,'$');
		//var id=url;
		var ts=data.ts||0;
		var text=data.text||"";

		var el=document.getElementById(id);
		if (el){
			var header = viewsData[url].header;
			$header.html("");
			$header.append($(header));
			addBackAndHome();
			doNavigation(el,(showView.ts||0)>ts?animBackwardName:animForwardName);
			showView.ts=ts;
		}else{
			loadPage(url,text,function(ret){
				$header.html("");
				$header.append($(ret.header));
				$viewport.append($(ret.viewport));
				data.header = ret.header;
				el=document.getElementById(url);
				el.id=id;
				addBackAndHome();
				loadView(el, function(View){
					if(View){
						new View({el: $(el)});
					}
					doNavigation(el,animForwardName);
					history.pushState({
						id:id,
						url: url,
                        text: text,
						ts:showView.ts=+new Date()
					},url,url);
				});
			});
		}

		showView.isFirst=true;

		//第一次进入 
//		if(!data){
//			console.log('!data')
//			var url = window.location.href; // slightly hacky (the setting), using getAttribute to keep it short
//			
//			viewsData[url] = {};
//			viewsData[url].url = url;
//			viewsData[url].text = $(section).html();
//			hist.unshift({
//				url:url	
//			})
//			var el = document.getElementById(url);
//			if(hist.length>1){
//				addBackAndHome();
//			}
//			console.log(viewsData[url])
//			history.pushState(viewsData[url], url, url);
//			loadView(el, function(View){
//				if(View){
//					new View({el: $(el)});
//				}
//				doNavigation(el,finalAnimationName)
//			})
			
//		}else{
//			var url = data.url; // slightly hacky (the setting), using getAttribute to keep it short
//			var id=url //getID(url);
//			var text = data.text;
//			var el = document.getElementById(id);
//			if(el){
////				removeBackAndHome();
//				var url = $(el).attr('id');
//				var header = viewsData[url].header;
//				$header.html("");
//				$header.append($(header));
//
//				if(!isBack){
//					hist.unshift({
//						url:url	
//					})
//					
//					// modify by cdchu start
////					if(hist.length>1){
//						addBackAndHome();
////					}
//					if (hist.length==0&&url!=homeUrl){
//						history.pushState(viewsData[url], url, url);
//					}
//					// modify by cdchu end
//
//				}else{
//					history.replaceState(viewsData[url], url, url);
//					if(hist.length>1){
//						addBackAndHome()
//					}
//					finalAnimationName = animBackwardName;
//				}
//				doNavigation(el,finalAnimationName)
//			}else{
//
//				hist.unshift({
//					url:url	
//				})
//				history.pushState(viewsData[url], url, url);
//				loadPage(url,text,function(ret){
////					var mainHTML = $(section).html();
//					$header.html("");
////					$viewport.html("");
//					$header.append($(ret.header));
//					$viewport.append($(ret.viewport));
//					data.header = ret.header;
////					$viewport.append($(html));
//					if(hist.length>1){
//						el = document.getElementById(url);
//						addBackAndHome()
//					}
//					loadView(el, function(View){
//						if(View){
//							new View({el: $(el)});
//						}
//						doNavigation(el,finalAnimationName)
//					})
//				});
//			}
//			
////		}
	}
	function bindPopstate(){
		if(support){
			$(window).bind('popstate', function (event) {
				showLoader();
				showView(event.originalEvent.state);
			});
		}
	}
	function loadPage(url,html,cb){
		function getData(models,cb){
			
			var len =models.length;
			var ajax = 0;
			var ret = [];
			//页面上model模板不存在，则直接执行end方法
			if(!len){
				end()
				return;
			}
			for(var i=0;i<len;i++){
				
				var model = models[i];
				var postdata = model.postdata;
				var url = model.url;

				$.ajax({type:'post',url:url,crossDomain:true,contentType:'application/json; charset=utf-8',
					data: JSON.stringify(postdata),
					success:function(data){
						ret.push(data);
						end();
					}
				}); 

			}
			function end(){
				
				ajax++;
				if(ajax>=len){
					cb(ret)
				}
			}
		}

		
		var models = Lizard.getModels(url,html);
			
		models = JSON.parse(models);
		
		getData(models,function (datas){
			var text = Lizard.render(url,html,datas);
			
			if(cb)cb(text);
		})
	}
	function getPageContent(){
		var html = document.body.innerHTML;
		html = html.replace(/amp;/g,'');
		return  html;
	}
	function getPageUrl(){
		var url = window.location.href;
		return url;
	}
	function getCurrentPage(){
		return $('.'+currentClass,section);
	}

	function doNavigation(el,finalAnimationName){
			var $currentPage = getCurrentPage();
			var fromPage = $currentPage;
			var toPage = $(el);
			console.log($currentPage);
			console.log(el);
			console.log(fromPage,toPage);
//			animation[finalAnimationName](toPage, fromPage);
			if($currentPage.length){
				fromPage.trigger('pagebeforehide');
				toPage.trigger('pagebeforeshow');
				fromPage.bind('webkitAnimationEnd', navigationEndHandler);
				fromPage.bind('webkitTransitionEnd', navigationEndHandler);
				scrollTo(0, 0);
				toPage.addClass(finalAnimationName + ' '+animInName+' '+currentClass);
				fromPage.addClass(finalAnimationName + ' '+animOutName);

				function navigationEndHandler(event) {
					fromPage.unbind('webkitAnimationEnd', navigationEndHandler);
					fromPage.unbind('webkitTransitionEnd', navigationEndHandler);
					fromPage.removeClass(finalAnimationName + ' '+animOutName+' '+currentClass);
					toPage.removeClass(finalAnimationName + ' '+ animInName);
					hideLoader();
					
					fromPage.trigger('pagehide');
					
					toPage.trigger('pageshow');
					//toPage.trigger('pagebeforecreate') This page was just inserted into the dom!
				}
			}else{
				toPage.trigger('pagebeforeshow');
				toPage.addClass(currentClass);
				hideLoader();
				toPage.trigger('pageshow');
				
			}
		
	}
	function isExternalLink(el) {
		var $el = $(el);
		return ($el.attr('target') === '_blank');// || $el.attr('rel') === 'external' || $el.is('a[href^="http://maps.google.com"], a[href^="mailto:"], a[href^="tel:"], a[href^="javascript:"], a[href*="youtube.com/v"], a[href*="youtube.com/watch"]'));
	};
	function showPageByHref(url){
		// modify by cdchu start
		var fUrl=typeof localRoute=='undefined'?url:localRoute.mapUrl(url);
		viewsData[url] = {};
		$.post(fUrl,{},function(data){
			viewsData[url].text = data;
			viewsData[url].url = url;
			showView(viewsData[url]);
		});
		// modify by cdchu end
	}
	function goTo(toPage){
		showLoader();
		// modify by cdchu start
		if (location.protocol=='file:'){
			var fUrl=typeof localRoute=='undefined'?toPage:localRoute.mapUrl(toPage);
			location.href=fUrl;
			return;
		}
		showPageByHref(toPage);
		// modify by cdchu end
	}
	function goBack(){
		// modify by cdchu start
		history.back();
		// modify by cdchu end
	}
	
	function bindEvents(){
		$body
			.bind('click', clickHandler)
			.bind('orientationchange', orientationChangeHandler)
//			.bind('submit', submitHandler)
//			.bind('tap', tapHandler)
//			.bind($.support.touch ? 'touchstart' : 'mousedown', touchStartHandler)
			.trigger('orientationchange');
	}
	function clickHandler(event){
		if (event.target.nodeName == 'A'||event.target.nodeName == 'I') {
			 if(support){
				for (var i=0, len=tapHandlers.length; i<len; i++) {
					var handler = tapHandlers[i];
					var supported = handler.isSupported(event);
					if (supported) {
						var flag = handler.fn(event);
						return flag;
					}
				}
			}
		}
	}
	function orientationChangeHandler() {
		scrollTo(0,0);
		orientation = Math.abs(window.orientation) === 90 ? 'landscape' : 'portrait';
		//$section.trigger('turn', {orientation: orientation});
	}
	function addTapHandler(tapHandler) {
		if (typeof(tapHandler.name) === 'string' && typeof(tapHandler.isSupported) === 'function' && typeof(tapHandler.fn) === 'function') {
			tapHandlers.push(tapHandler);
		}
	}
	function addDefaultTapHandlers() {
		addTapHandler({
			name: 'external-link',
			isSupported: function(event) {
				
				return isExternalLink(event.target);
			},
			fn: function(event) {
				event.preventDefault();
				return true;
			}
		});
		addTapHandler({
			name: 'back-selector',
			isSupported: function(event) { backClass
				return $(event.target).hasClass('returnico');
			},
			fn: function(event) {
				// User clicked or tapped a back button
				goBack();
			}
		});
		addTapHandler({
			name: 'home-selector',
			isSupported: function(event) { backClass
				return $(event.target).hasClass('icon_home');
			},
			fn: function(event) {
				// User clicked or tapped a back button
				goTo(homeUrl);
			}
		});
		addTapHandler({
			name: 'standard',
			isSupported: function(event) {
				return true;
			},
			fn: function(event) {
				showLoader();
				var url = event.target.getAttribute('href');
				goTo(url);
				return false;
			}
		});
	}
	function loadView(el, callback) {
		var controllers = $('script[type="text/controller"]',el);
		if(controllers.length>0){
			var controller = controllers[0];
			var path = controller.src;
			requirejs([path], function (View) {
				callback && callback(View);
			});
		}else{
			callback && callback(null);
		}
    }
	function initController(html){
		var controllers = Lizard.getControllers(html);
			controllers = JSON.parse(controllers);
		var _getScript = function(url, callback) {
			var head = document.getElementsByTagName('head')[0],
				js = document.createElement('script');

			js.setAttribute('type', 'text/javascript'); 
			js.setAttribute('src', url); 

			head.appendChild(js);

			//执行回调
			var callbackFn = function(){
					if(typeof callback === 'function'){
						callback();
					}
				};

			if (document.all) { //IE
				js.onreadystatechange = function() {
					if (js.readyState == 'loaded' || js.readyState == 'complete') {
						callbackFn();
					}
				}
			} else {
				js.onload = function() {
					callbackFn();
				}
			}
		}
		for(var i=0;i<controllers.length;i++){
			var controller = controllers[i];
			_getScript(controller,function(){})
		}
	}

	function intApp(){
		var url = getPageUrl();
		var text = getPageContent();

		loadPage(url,text,function(ret){
		
//			{
//				header:
//				viewport
//			}
			
			$header.html("");
			$viewport.html("");
			$header.append($(ret.header));
			$viewport.append($(ret.viewport));

//			var el = document.getElementById(url);

			// modify by cdchu start
			addLoaderStyle(loaderStyle);
			// modify by cdchu end

			addLoader();

			showLoader();
			
			viewsData[url] = {};
			viewsData[url].url = url;
			viewsData[url].text = text;
			viewsData[url].header = ret.header;
			var el = document.getElementById(url);
			var id="$"+getGuid()+"|"+escape(url).replace(/%/g,'$');
			el.id=id;
			addBackAndHome();
			loadView(el, function(View){
				if(View){
					new View({el: $(el)});
				}
				showView.firstState={
					id:id,
					url: url,
					text: text,
					ts:showView.ts=+new Date()
				};
				doNavigation(el,animForwardName);
			})
			
			bindEvents();
			//initController(html)
		});
	}
	//Document ready stuff
	function start() {
		if(window.server){
			var url = getPageUrl().replace(/\/html5\//,'/webapp/');
			var id = url;
			var el = document.getElementById(url);
			loadView(el, function(View){
				if(View){
					new View({el: $(el)});
				}
				showView.firstState={
					id:id,
					url: url,
                    text: document.documentElement.innerHTML,
					ts:showView.ts=+new Date()
				};
				doNavigation(el,animForwardName);
			})
		}else{
			bindPopstate();
			addDefaultTapHandlers()
			intApp();
		}
		
	}
	starter(start);
	//对外暴露的方法
	Lizard.goBack = goBack;
	Lizard.goTo = goTo;

	/*
	goBack
	goTo
	添加动画效果的支持
	*/
	// 缓存视图数量，默认0缓存全部
	//var viewCacheCount = 0;
	/*
		//http://kayosite.com/web-app-by-jquery-mobile-and-html5-events-in-detail.html

		Orientation change event 设备方向变化事件 
		Page events 页面事件的支持
			Page load events 页面加载事件
			Page change events  页面跳转事件 
			Page show/hide events 页面显示/隐藏事件 
			Page initialization events 页面初始化事件
			Page remove events 页面移除事件
		touch events 触摸事件
		Scroll events 滚屏事件
		
		back
		foward
		dialog

		
	*/
	
	// modify by cdchu start
	if (location.protocol=='file:'){
		require(['../res/localRoute.js']);
	}
	// modify by cdchu end

});