define([siteBaseUrl+'Res/pageView.js'],function(pageView){
	var groupView = pageView.extend({
		pagebeforehide:function(){
			console.log('pagebeforehide',this.id)
		},
		pagehide:function(){
			console.log('pagehide',this.id)				
		},
		pagebeforeshow:function(){
			console.log('pagebeforeshow',this.id)		
		},
		pageshow:function(){
			console.log('pageshow',this.id)			
		},
		events:{
			"click #searchlistsubmit": "groupSearch"
		},
		groupSearch: function () {
			console.log('groupSearch')
			var action = window.isIpad?"vacationlistipad":"vacationlist"
			if(window.server){
			    window.location.href = siteBaseUrl + action + "/2/2/三亚";
			}else{
			    Lizard.goTo(siteBaseUrl + action + "/2/2/三亚");
			}
		}
	})
	return groupView;
});


 