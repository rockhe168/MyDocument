define([siteBaseUrl+'Res/pageView.js'],function(pageView){
	var groupView = pageView.extend({
		pagebeforehide:function(){
			console.log('pagebeforehide',this.id)
		},
		pagehide:function(){
			console.log('pagehide',this.id)				
		},
		pagebeforeshow:function(){
			console.log('pagebeforeshow',this.id)		
		},
		pageshow:function(){
			console.log('pageshow',this.id)			
		},
		events: {
			"click .hot_list_tab": "detail"
		},
		detail:function(){
			var action = window.isIpad?"detailipad":"detail";
			if(window.server){
			    window.location.href = siteBaseUrl + action + "/1740980/2";
			}else{
			    Lizard.goTo(siteBaseUrl + action + "/1740980/2");
			}
		}
	})
	return groupView;
});


 