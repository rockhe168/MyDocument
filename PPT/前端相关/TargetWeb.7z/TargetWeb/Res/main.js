$(function(){
	if(!window.server){
		function List(){
			this.init()
		}
		List.prototype = {
			init:function(){
				$('#main').bind('click', function (event) {
					console.log('click')
					var title;
					if (event.target.nodeName == 'A') {
						 if(!support){
							
						 }else{
							event.preventDefault();
							var url = event.target.getAttribute('href'); // slightly hacky (the setting), using getAttribute to keep it short
							var title = url;
							if(!all_data[title]){
								all_data[title] = {};
								$.ajax({type:'get',url:url,success:function(data){
									console.log('success')
									all_data[title].text = data;
									all_data[title].url = url;
									end();
								}})
							}else{
								end();	
							}
							function end(){
								console.log('end')
								history.pushState(all_data[title], title, url);
								reportData(all_data[title]);
							}
						 }
					}
				});
			}
		}
		var llist = new List();
	}

})