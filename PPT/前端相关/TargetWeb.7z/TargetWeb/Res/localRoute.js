// modify by cdchu start
(function(){
	var root;
	if (typeof window!='undefined'){
		root=window;
	}
	if (typeof global!='undefined'){
		root=global;
	}
	if (root.localRoute){
		return;
	}

	function reString(str){
		var h={
			'\r':'\\r',
			'\n':'\\n',
			'\t':'\\t'
		};
		var re1=/([\.\\\/\+\*\?\[\]\{\}\(\)\^\$\|])/g;
		var re2=/[\r\t\n]/g;
		return str.replace(re1,"\\$1").replace(re2,function(a){
			return h[a];
		});
	}

	root.localRoute={
		config:{},
		addConfig:function(obj){
			for (var urlschema in obj){
				if (obj.hasOwnProperty(urlschema)){
					this.config[urlschema]=obj[urlschema];
				}
			}
		},
		mapUrl:function(url){
			var absoluteUrl=url;
			if (!/:\/\//.test(absoluteUrl)){
				if (/^\/\//.test(absoluteUrl)){
					absoluteUrl=location.protocol+absoluteUrl;
				}else if (/^\//.test(absoluteUrl)){
					absoluteUrl=location.protocal+'//'+location.host+absoluteUrl;
				}else{
					absoluteUrl=location.href.replace(/[\?#].+$/,'').replace(/[^\/]+$/,'')+absoluteUrl;
				}
			}
			for (var urlschema in this.config){
				var paraArr=[];
				var reStr=urlschema.replace(/\{(.+?)\}|[^\{\}]+/g,function(a,b){
					if (b){
						paraArr.push(b);
						return "([^\\\/]*)";
					}else{
						return reString(a);
					}
				});
				var re=new RegExp(reStr,'i');
				var tUrl=absoluteUrl.replace(/[\?#].+$/g,'');
				var matches=tUrl.match(re);
				if (matches){
					var queryArr=[];
					for (var i=0;i<paraArr.length;i++){
						queryArr.push(encodeURIComponent(paraArr[i])+'='+encodeURIComponent(matches[i+1]));
					}
					var rUrl=this.config[urlschema];
					rUrl=rUrl.replace(/^([^#]*)/,function(a){
						return a.replace(/(\?.*)?$/,function(a,b){
							return (b?'&':'?')+queryArr.join('&');
						});
					});
					return rUrl;
				}
			}
			return absoluteUrl;
		}
	}
})();


localRoute.addConfig({
	'/index':'index.html',
	'/indexipad':'indexipad.html',
	'/vacationlist/{salecity}/{startcity}/{key}':'vacationlist.html',
	'/vacationlistipad/{salecity}/{startcity}/{key}':'vacationlistipad.html',
	'/detail/{pid}/{dcid}':'detail.html',
	'/detailipad/{pid}/{dcid}':'detailipad.html'
});

// modify by cdchu end
