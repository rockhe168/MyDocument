﻿ // define(['cUICore',
 //     'cUISlide',
 //     'cChineseCal',
 //     'cCalendar',
 //     'cHistory'],
 // function (cui_core, cui_slide, chineseCalendar, cui_calendar, cui_history, cui_cityList) {
 //     var cui = cui_core;
 //     cui.Slide = cui_slide;
 //     cui.chineseCalendar = chineseCalendar;
 //     cui.Calendar = cui_calendar;
 //     cui.History = cui_history;
 //     return cui;
 // });

//define(['cUICore', 'cHistory'], function (cui_core, cui_history) {
// var cui = cui_core;
// cui.History = cui_history;
// return cui;
//});

define(['cUICore'], function (cuiCore) {
  return cuiCore;
});