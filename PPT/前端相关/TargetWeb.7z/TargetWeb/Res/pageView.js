define(function(){
	var pageView = Backbone.View.extend({
		initialize:function(){
			this.$el
			.bind('pagebeforehide',this.pagebeforehide)
			.bind('pagebeforeshow',this.pagebeforeshow)
			.bind('pagehide',this.pagehide)
			.bind('pageshow',this.pageshow)
			this.id = this.$el.attr("id");
		},
		pagebeforehide:function(){
			console.log('pagebeforehide')
		},
		pagebeforeshow:function(){
			console.log('pagebeforeshow')		
		},
		pagehide:function(){
			console.log('pagehide')				
		},
		pageshow:function(){
			console.log('pageshow')			
		}
	})
	return pageView;
});