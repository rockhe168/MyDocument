function List(){
	this.init()
}
List.prototype = {
	init:function(){
		
	}
}
var llist = new List();